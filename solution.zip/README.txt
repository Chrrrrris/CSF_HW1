# CSF_HW1

Project Members: Chris Wang, Emily Song

Contributions:
Assignment 1 MileStone1:


    Chris Wang: Completed all the required functions for MS1.
    
    Emily Song: Reviewed the completed functions and ran memory tests.

Assignment 1 MileStone2:


    Chris Wang: 
    
    Emily Song: 
